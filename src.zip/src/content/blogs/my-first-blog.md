---
title: My First Blog Post
slug: my-first-blog
date: '2025-03-12'
tags:
  - Next.js
  - MongoDB
  - Markdown
description: A blog about Next.js and MongoDB.
---

## Welcome to My Blog!
This is a sample blog post written in **Markdown**.
