// This script converts the default SVG OG image to PNG
// Usage: node scripts/generate-og-image.js

const fs = require('fs');
const path = require('path');
const { createCanvas, loadImage } = require('canvas');
const sharp = require('sharp');

// Paths
const svgPath = path.join(__dirname, '../public/images/blog-default-og.svg');
const pngPath = path.join(__dirname, '../public/images/blog-default-og.jpg');

async function convertSvgToPng() {
  try {
    console.log('Converting default OG image from SVG to JPG...');
    
    // Read the SVG file
    const svgBuffer = fs.readFileSync(svgPath);
    
    // Convert SVG to PNG using sharp
    await sharp(svgBuffer)
      .resize(1200, 630)
      .toFormat('jpeg')
      .jpeg({ quality: 90 })
      .toFile(pngPath);
    
    console.log(`Successfully created ${pngPath}`);
  } catch (error) {
    console.error('Error converting SVG to JPG:', error);
  }
}

// Run the conversion
convertSvgToPng(); 